﻿# PKOS 탐색기 연결: pkos-open: 링크를 받아 내 드라이브 안의 파일·폴더를 탐색기에서 보여 준다.
# 파일을 실행하지 않는다. 파일이면 탐색기에서 그 파일을 선택하고, 폴더면 그 폴더를 연다.
# 링크 형식: pkos-open:?mode=select|folder&path=<내 드라이브 기준 경로, URL 인코딩>
param([string]$Url = '', [switch]$DryRun)
$ErrorActionPreference = 'Stop'

function Show-Note([string]$text) {
  if ($DryRun) { Write-Output "NOTE $text"; return }
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show($text, 'PKOS 탐색기 연결') | Out-Null
}

if ($Url -notmatch '^pkos-open:') { Show-Note '올바른 PKOS 링크가 아닙니다.'; exit 1 }
$query = @{}
foreach ($pair in ($Url -replace '^pkos-open:/*\??', '').Split('&')) {
  $kv = $pair.Split('=', 2)
  if ($kv.Count -eq 2) { $query[$kv[0]] = [Uri]::UnescapeDataString($kv[1].Replace('+', '%20')) }
}
$rel = [string]$query['path']
$mode = if ($query['mode'] -eq 'folder') { 'folder' } else { 'select' }

# 내 드라이브 기준 상대 경로만 받는다: 드라이브 문자, 맨 앞 구분자, '..' 단계는 거부한다.
$parts = $rel -split '[\\/]' | Where-Object { $_ -ne '' }
if (-not $rel -or $rel -match ':' -or $rel -match '^[\\/]' -or ($parts -contains '..') -or ($parts -contains '.')) {
  Show-Note '내 드라이브 안의 경로만 열 수 있습니다.'; exit 1
}

# Drive for desktop의 '내 드라이브'(또는 'My Drive')가 있는 드라이브를 찾는다(보통 G:).
$root = $null
foreach ($d in (Get-PSDrive -PSProvider FileSystem | Sort-Object { $_.Name -ne 'G' })) {
  foreach ($name in @('내 드라이브', 'My Drive')) {
    $candidate = Join-Path ($d.Name + ':\') $name
    if (Test-Path -LiteralPath $candidate -PathType Container) { $root = $candidate; break }
  }
  if ($root) { break }
}
if (-not $root) { Show-Note '구글 드라이브(내 드라이브)를 찾지 못했습니다. Drive for desktop이 켜져 있는지 확인해 주세요.'; exit 1 }

$full = Join-Path $root ($parts -join '\')
if (-not $full.StartsWith($root + '\')) { Show-Note '내 드라이브 안의 경로만 열 수 있습니다.'; exit 1 }

if (Test-Path -LiteralPath $full -PathType Leaf) {
  $explorerArgs = if ($mode -eq 'folder') { '"' + [IO.Path]::GetDirectoryName($full) + '"' } else { '/select,"' + $full + '"' }
} elseif (Test-Path -LiteralPath $full -PathType Container) {
  $explorerArgs = '"' + $full + '"'
} else {
  # 파일이 옮겨졌거나 아직 내려받지 않은 경우: 남아 있는 가장 가까운 상위 폴더를 연다.
  $up = [IO.Path]::GetDirectoryName($full)
  while ($up -and $up.Length -gt $root.Length -and -not (Test-Path -LiteralPath $up -PathType Container)) { $up = [IO.Path]::GetDirectoryName($up) }
  if (-not $up -or $up.Length -lt $root.Length) { $up = $root }
  $explorerArgs = '"' + $up + '"'
  Show-Note ("파일을 찾지 못해 가장 가까운 폴더를 엽니다.`n" + $full)
}

if ($DryRun) { Write-Output "explorer.exe $explorerArgs"; exit 0 }
Start-Process -FilePath "$env:WINDIR\explorer.exe" -ArgumentList $explorerArgs

﻿# PKOS 탐색기 연결 제거: 설치 때 만든 등록과 파일만 지운다.
$ErrorActionPreference = 'Stop'
$key = 'HKCU:\Software\Classes\pkos-open'
if (Test-Path $key) { Remove-Item -Path $key -Recurse -Force }
$script = Join-Path $env:LOCALAPPDATA 'PKOS\pkos-open.ps1'
if (Test-Path -LiteralPath $script) { Remove-Item -LiteralPath $script -Force }
Write-Host 'PKOS 탐색기 연결을 제거했습니다.'

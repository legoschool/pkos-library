﻿# PKOS 탐색기 연결 설치: 현재 사용자(HKCU)에만 pkos-open: 링크를 등록한다. 관리자 권한이 필요 없다.
# 지울 때는 같은 폴더의 '탐색기 연결 제거.cmd'를 실행한다.
$ErrorActionPreference = 'Stop'
$dest = Join-Path $env:LOCALAPPDATA 'PKOS'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
$script = Join-Path $dest 'pkos-open.ps1'
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'pkos-open.ps1') -Destination $script -Force
$key = 'HKCU:\Software\Classes\pkos-open'
New-Item -Path $key -Force | Out-Null
Set-ItemProperty -Path $key -Name '(Default)' -Value 'URL:PKOS 탐색기 연결'
Set-ItemProperty -Path $key -Name 'URL Protocol' -Value ''
New-Item -Path "$key\shell\open\command" -Force | Out-Null
$ps = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
Set-ItemProperty -Path "$key\shell\open\command" -Name '(Default)' -Value ('"' + $ps + '" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + $script + '" -Url "%1"')
Write-Host 'PKOS 탐색기 연결을 설치했습니다.'
Write-Host '앱의 탐색기 버튼을 처음 누르면 브라우저가 "열기"를 묻습니다. 허용해 주세요.'
